-- App Build v14 Production PostgreSQL Schema
CREATE TABLE IF NOT EXISTS appbuild_kv (
  collection VARCHAR(64) NOT NULL,
  item_key VARCHAR(255) NOT NULL,
  user_id VARCHAR(128),
  payload JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (collection, item_key)
);

CREATE INDEX IF NOT EXISTS idx_appbuild_kv_user
  ON appbuild_kv (collection, user_id);
