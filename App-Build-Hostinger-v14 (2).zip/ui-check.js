let selectedFile=null, selectedSources=[], generatedProjectReady=false, currentBuildId=null, currentWorkspacePath='project.zip', latestRun=null, failedRunId=null, pendingFixes=[], pollTimer=null, chatHistory=[], lastUserIdea='';
let vaultState={geminiConfigured:false,radoxConfigured:false,openaiConfigured:false,githubConfigured:false};
const $=id=>document.getElementById(id);

function toggleDrawer(open){$('settingsDrawer').classList.toggle('open',open);$('backdrop').style.display=open?'block':'none'}
function focusChat(){$('chatInput').focus()}
function autoGrow(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,140)+'px'}
function toggleAttach(){$('attachMenu').classList.toggle('hidden')}
function chooseZip(){$('attachMenu').classList.add('hidden');$('project').click()}
function chooseFiles(){$('attachMenu').classList.add('hidden');$('sourceFiles').click()}
function showBuildSettings(){$('attachMenu').classList.add('hidden');$('buildTools').classList.remove('hidden');$('buildTools').scrollIntoView({behavior:'smooth',block:'nearest'})}
function voiceNotReady(){addChat('agent','Voice input browser/device support ke hisaab se enable kiya jayega. Filhaal aap type karke baat kar sakte hain.')}
function newChat(){
 $('chatMessages').innerHTML='';$('dynamicActions').innerHTML='';$('projectArea').innerHTML='';$('progressArea').innerHTML='';$('downloadArea').innerHTML='';
 $('welcome').classList.remove('hidden');chatHistory=[];generatedProjectReady=false;selectedFile=null;selectedSources=[];focusChat();
}
function log(s){$('terminal').textContent+=`\n[${new Date().toLocaleTimeString()}] ${s}`;$('terminal').scrollTop=$('terminal').scrollHeight}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

let activeAIProvider='gemini';
function providerLabel(p){return p==='radox'?'Radox AI':p==='openai'?'OpenAI (GPT)':p==='none'?'No backup':'Google Gemini'}

function setActiveProvider(){
 activeAIProvider=$('activeProvider').value;
 const backup=$('fallbackProvider').value;
 $('activeProviderStatus').textContent='Primary: '+providerLabel(activeAIProvider)+' · Backup: '+providerLabel(backup);
 $('topProviderBadge').textContent=providerLabel(activeAIProvider);
}

// Restore saved encrypted session configuration from backend on page load
async function restoreServerSession(){
 try{
  const r=await fetch('/api/session');
  const d=await r.json();
  if(!r.ok||!d.ok)return;
  const s=d.saved||{};
  vaultState=s;
  if(s.provider)$('activeProvider').value=s.provider;
  if(s.fallbackProvider)$('fallbackProvider').value=s.fallbackProvider;
  if(s.geminiModel)$('geminiModel').value=s.geminiModel;
  if(s.radoxModel)$('radoxModel').value=s.radoxModel;
  if(s.radoxBaseUrl)$('radoxBaseUrl').value=s.radoxBaseUrl;
  if(s.openaiModel)$('openaiModel').value=s.openaiModel;
  if(s.owner)$('owner').value=s.owner;
  if(s.repo)$('repo').value=s.repo;
  if(s.geminiConfigured)$('geminiStatus').textContent=`Saved in server vault (${s.geminiMasked}) ✓`;
  if(s.radoxConfigured)$('radoxStatus').textContent=`Saved in server vault (${s.radoxMasked}) ✓`;
  if(s.openaiConfigured)$('openaiStatus').textContent=`Saved in server vault (${s.openaiMasked}) ✓`;
  if(s.githubConfigured)$('connection').textContent=`Saved in server vault: ${s.owner}/${s.repo} (${s.githubMasked}) ✓`;
  setActiveProvider();
 }catch(e){console.warn('Session init note:',e.message)}
}
window.addEventListener('DOMContentLoaded',restoreServerSession);

$('project').addEventListener('change',e=>{
 selectedFile=e.target.files[0]||null;
 if(selectedFile){
  $('welcome').classList.add('hidden');
  $('projectArea').innerHTML=`<div class="project-card"><div class="project-row"><div class="file-icon">ZIP</div><div class="project-meta"><b>${escapeHtml(selectedFile.name)}</b><small>${(selectedFile.size/1024/1024).toFixed(2)} MB · Android Project ZIP attached</small></div><span class="ready">● Ready</span></div></div>`;
  addChat('agent','Project ZIP attach ho gaya! Ab aap neeche Build APK + Signed AAB button daba sakte hain.');
  showBuildSettings();
 }
});

$('sourceFiles').addEventListener('change',e=>{
 selectedSources=Array.from(e.target.files||[]);
 if(selectedSources.length){
  $('welcome').classList.add('hidden');
  $('projectArea').innerHTML=`<div class="project-card"><div class="project-row"><div class="file-icon">FILES</div><div class="project-meta"><b>${selectedSources.length} source files selected</b><small>${(selectedSources.reduce((n,f)=>n+f.size,0)/1024).toFixed(1)} KB · Source files attached</small></div><span class="ready">● Ready</span></div></div>`;
  addChat('agent','Source files attach ho gayi hain. Main inhe complete Gradle project mein pack karke build karunga.');
  showBuildSettings();
 }
});

function credentials(){
 return {
  owner:$('owner').value.trim(),
  repo:$('repo').value.trim(),
  token:$('token').value.trim(),
  provider:$('activeProvider').value,
  fallbackProvider:$('fallbackProvider').value,
  geminiKey:$('geminiKey').value.trim(),
  geminiModel:$('geminiModel').value.trim(),
  radoxKey:$('radoxKey').value.trim(),
  radoxModel:$('radoxModel').value.trim(),
  radoxBaseUrl:$('radoxBaseUrl').value.trim(),
  openaiKey:$('openaiKey').value.trim(),
  openaiModel:$('openaiModel').value.trim()
 };
}

async function api(path,extra={}){
 const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...credentials(),...extra})});
 const d=await r.json();
 if(!r.ok||!d.ok)throw Error(d.error||'Request failed');
 return d;
}

// GitHub Connection Controls
async function testGithub(){
 try{
  $('connection').textContent='Checking GitHub repository & Actions permissions...';
  const d=await api('test');
  vaultState.githubConfigured=true;
  $('token').value='';
  $('connection').textContent='Connected ✓ '+d.repository+' · '+(d.private?'Private':'Public')+' (Write + Actions Verified)';
  log('GitHub connection verified: '+d.repository);
 }catch(e){$('connection').textContent='Connection error: '+e.message}
}

async function removeGithub(){
 await fetch('/api/remove-credential',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:'github'})});
 $('owner').value='';$('repo').value='';$('token').value='';vaultState.githubConfigured=false;
 $('connection').textContent='GitHub credentials removed.';
}

// Gemini Controls (Strict Direct Test — No Fallback!)
function replaceGeminiKey(){$('geminiKey').value='';$('geminiKey').focus();$('geminiStatus').textContent='Nayi Gemini key paste karein, phir Test Gemini Connection dabayein.'}
async function removeGeminiKey(){
 await fetch('/api/remove-credential',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:'gemini'})});
 $('geminiKey').value='';vaultState.geminiConfigured=false;$('geminiStatus').textContent='Gemini API key server vault se remove kar di gayi.';
}
async function testGemini(){
 const key=$('geminiKey').value.trim();
 if(!key&&!vaultState.geminiConfigured){$('geminiStatus').textContent='Pehle Gemini API key enter karein.';return}
 $('geminiStatus').textContent='Testing Gemini API directly...';
 try{
  const d=await api('test-gemini',{geminiKey:key,geminiModel:$('geminiModel').value.trim()});
  vaultState.geminiConfigured=true;$('geminiKey').value='';
  if(d.model)$('geminiModel').value=d.model;
  $('geminiStatus').textContent='Connected ✓ Model: '+d.model+' · '+d.response;
 }catch(e){$('geminiStatus').textContent='Connection failed: '+e.message}
}
async function loadGeminiModels(){
 try{
  $('geminiStatus').textContent='Loading Gemini models...';
  const d=await api('gemini-models');
  const ids=(d.models||[]).map(m=>m.id);
  if(ids.length&&!$('geminiModel').value)$('geminiModel').value=ids[0];
  $('geminiStatus').textContent='Models available: '+ids.slice(0,8).join(', ');
 }catch(e){$('geminiStatus').textContent='Model list error: '+e.message}
}

// Radox AI Controls
function replaceRadoxKey(){$('radoxKey').value='';$('radoxKey').focus();$('radoxStatus').textContent='Nayi Radox key paste karein, phir Test Radox Connection dabayein.'}
async function removeRadoxKey(){
 await fetch('/api/remove-credential',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:'radox'})});
 $('radoxKey').value='';vaultState.radoxConfigured=false;$('radoxStatus').textContent='Radox API key server vault se remove kar di gayi.';
}
async function testRadox(){
 const key=$('radoxKey').value.trim();
 if(!key&&!vaultState.radoxConfigured){$('radoxStatus').textContent='Pehle Radox API key enter karein.';return}
 $('radoxStatus').textContent='Testing Radox API directly...';
 try{
  const d=await api('test-radox',{radoxKey:key,radoxModel:$('radoxModel').value.trim(),radoxBaseUrl:$('radoxBaseUrl').value.trim()});
  vaultState.radoxConfigured=true;$('radoxKey').value='';
  if(d.model)$('radoxModel').value=d.model;
  $('radoxStatus').textContent='Connected ✓ Model: '+d.model+' · '+d.response;
 }catch(e){$('radoxStatus').textContent='Connection failed: '+e.message}
}
async function loadRadoxModels(){
 try{
  $('radoxStatus').textContent='Loading Radox models...';
  const d=await api('radox-models');
  const ids=(d.models||[]).map(m=>m.id);
  if(ids.length)$('radoxModel').value=ids[0];
  $('radoxStatus').textContent=ids.length?'Models loaded (selected '+ids[0]+'): '+ids.slice(0,8).join(', '):'No models returned.';
 }catch(e){$('radoxStatus').textContent='Model list error: '+e.message}
}

// OpenAI Controls
function replaceOpenAIKey(){$('openaiKey').value='';$('openaiKey').focus();$('openaiStatus').textContent='Nayi OpenAI key paste karein, phir Test OpenAI Connection dabayein.'}
async function removeOpenAIKey(){
 await fetch('/api/remove-credential',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({target:'openai'})});
 $('openaiKey').value='';vaultState.openaiConfigured=false;$('openaiStatus').textContent='OpenAI API key server vault se remove kar di gayi.';
}
async function testOpenAI(){
 const key=$('openaiKey').value.trim();
 if(!key&&!vaultState.openaiConfigured){$('openaiStatus').textContent='Pehle OpenAI API key enter karein.';return}
 $('openaiStatus').textContent='Testing OpenAI API directly...';
 try{
  const d=await api('test-openai',{openaiKey:key,openaiModel:$('openaiModel').value.trim()});
  vaultState.openaiConfigured=true;$('openaiKey').value='';
  if(d.model)$('openaiModel').value=d.model;
  $('openaiStatus').textContent='Connected ✓ Model: '+d.model+' · '+d.response;
 }catch(e){$('openaiStatus').textContent='Connection failed: '+e.message}
}
async function loadOpenAIModels(){
 try{
  $('openaiStatus').textContent='Loading OpenAI models...';
  const d=await api('openai-models');
  const ids=(d.models||[]).map(m=>m.id);
  if(ids.length&&!$('openaiModel').value)$('openaiModel').value=ids[0];
  $('openaiStatus').textContent='Models available: '+ids.slice(0,10).join(', ');
 }catch(e){$('openaiStatus').textContent='Model list error: '+e.message}
}

function addChat(role,text){
 $('welcome').classList.add('hidden');
 const row=document.createElement('div');row.className='message '+(role==='user'?'user':'agent');
 if(role!=='user'){
  const mark=document.createElement('div');mark.className='bot-mark';
  mark.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2 22 7v10l-10 5L2 17V7l10-5Z"/><path d="m2 7 10 6 10-6M12 13v9"/></svg>';
  row.append(mark);
 }
 const bubble=document.createElement('div');bubble.className='bubble';bubble.textContent=text;
 row.append(bubble);$('chatMessages').append(row);$('chatScroll').scrollTop=$('chatScroll').scrollHeight;
}

function showDynamicActions(){
 $('dynamicActions').innerHTML=`
 <div class="message-actions">
 <button class="action-chip" onclick="selectAction('APK Banaye')"><svg viewBox="0 0 48 48"><path fill="#16a34a" d="M13 17 8 9l2-1 5 8m16 0 5-8 2 1-5 8M10 20h28v17a3 3 0 0 1-3 3H13a3 3 0 0 1-3-3V20Z"/><circle cx="18" cy="26" r="2" fill="white"/><circle cx="30" cy="26" r="2" fill="white"/></svg><span><b>APK Banaye</b><small>Android App</small></span></button>
 <button class="action-chip" onclick="selectAction('AAB Banaye')"><svg viewBox="0 0 48 48"><path fill="#34a853" d="M8 5v38l19-19Z"/><path fill="#4285f4" d="m8 5 25 14-6 5Z"/><path fill="#fbbc04" d="m27 24 6-5 8 5-8 5Z"/><path fill="#ea4335" d="m8 43 25-14-6-5Z"/></svg><span><b>AAB Banaye</b><small>Play Store</small></span></button>
 <button class="action-chip" onclick="selectAction('Fix / Improve')"><svg viewBox="0 0 48 48" fill="none" stroke="#2563eb" stroke-width="5" stroke-linecap="round"><path d="m10 9 8 8m-3-11 8 8-7 7-8-8m20 18 8 8m-2-13 8 8-7 7-8-8"/><path d="m17 31 14-14"/></svg><span><b>Fix / Improve</b><small>Error, Bug, Optimize</small></span></button>
 <button class="action-chip" onclick="selectAction('APK Download')"><svg viewBox="0 0 48 48" fill="none" stroke="#7c3aed" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><path d="M24 5v24m-10-10 10 10 10-10M8 31v9h32v-9"/></svg><span><b>APK Download</b><small>Build ke baad</small></span></button>
 </div>`;
}

async function selectAction(action){
 addChat('user',action);chatHistory.push({role:'user',text:action});
 if(action==='APK Banaye'||action==='AAB Banaye'){
  showBuildSettings();
  if(!selectedFile&&!selectedSources.length&&!generatedProjectReady){
   await generateAndroidProjectFromChat(lastUserIdea||'Complete Android application as discussed in chat');
  } else {
   addChat('agent','Project ready hai! Ab "Build APK + Signed AAB" button dabayein.');
  }
 } else if(action==='Fix / Improve'){
  showBuildSettings();
  if(failedRunId){
   $('repairPanel').classList.remove('hidden');
   diagnoseFailure();
  } else {
   addChat('agent','Aap chat mein bata sakte hain ki app mein kya improve ya fix karna hai, ya existing files attach kar sakte hain.');
  }
 } else if(action==='APK Download'){
  if($('outputs').children.length){
   $('outputs').classList.remove('hidden');
   $('outputs').scrollIntoView({behavior:'smooth'});
  } else if(generatedProjectReady){
   window.location.href='/api/project-zip?projectId=default';
  } else {
   addChat('agent','Abhi build complete nahi hua hai. Pehle APK Banaye par click karke cloud build chalayein.');
  }
 }
}

function hasAnyAiConfigured(){
 const c=credentials();
 return Boolean(c.geminiKey||c.radoxKey||c.openaiKey||vaultState.geminiConfigured||vaultState.radoxConfigured||vaultState.openaiConfigured);
}

async function generateAndroidProjectFromChat(customIdea){
 $('attachMenu').classList.add('hidden');
 const idea=customIdea||lastUserIdea||$('chatInput').value.trim()||$('appName').value.trim();
 if(!idea){
  addChat('agent','Pehle chat mein batayein ki aapko kaisa Android app banana hai (jaise: "Video player app banana hai").');
  return;
 }
 if(!hasAnyAiConfigured()){
  toggleDrawer(true);
  addChat('agent','Project generate karne ke liye Settings mein Gemini, Radox AI, ya OpenAI ki API key save karein.');
  return;
 }
 showBuildSettings();
 $('genProjectBtn').disabled=true;
 $('status').textContent='AI Agent native Android Gradle + Kotlin project generate kar raha hai...';
 addChat('agent','Theek hai! Main aapke liye complete Native Android Studio project (Gradle + Kotlin + XML) generate kar raha hoon. Thoda intezar kijiye...');
 try{
  const d=await api('generate-project',{
   idea,
   appName:$('appName').value.trim(),
   packageId:$('packageId').value.trim(),
   versionCode:$('versionCode').value
  });
  generatedProjectReady=true;
  $('appName').value=d.appName;
  $('packageId').value=d.packageId;
  const providerTag=d.fallback?`[Failover: ${providerLabel(d.fallback.from)} → ${providerLabel(d.fallback.to)}]`:`[AI: ${providerLabel(d.usedProvider)}]`;
  $('projectArea').innerHTML=`
   <div class="project-card">
    <div class="project-row">
     <div class="file-icon">KT</div>
     <div class="project-meta">
      <b>${escapeHtml(d.appName)} (${escapeHtml(d.packageId)})</b>
      <small>${d.fileCount} Native Android Gradle files generated · ${providerTag}</small>
     </div>
     <a class="btn" href="/api/project-zip?projectId=default" style="text-decoration:none;font-size:12px">⬇ Source ZIP</a>
    </div>
   </div>`;
  $('status').textContent='Android project ready hai! Ab "Build APK + Signed AAB" par click karein.';
  addChat('agent',`${providerTag}\n${d.summary}\n\nProject ke ${d.fileCount} files tayyar hain. Ab aap seedha "Build APK + Signed AAB" daba sakte hain ya Source ZIP download kar sakte hain.`);
 }catch(e){
  $('status').textContent='Generation error: '+e.message;
  addChat('agent','Project generation mein error aaya: '+e.message);
 }finally{
  $('genProjectBtn').disabled=false;
 }
}

async function sendChat(){
 const message=$('chatInput').value.trim();
 if(!message)return;
 lastUserIdea=message;
 $('chatInput').value='';$('chatInput').style.height='auto';
 addChat('user',message);chatHistory.push({role:'user',text:message});
 const intent=/apk|aab|play store|build|ban[a-z]*|app|player|calculator|game|fix|error|bug|download/i.test(message);

 try{
  if(!hasAnyAiConfigured()){
   addChat('agent','AI chat aur code generation shuru karne ke liye upar ☰ menu ya ⚙ Settings kholkar apni Gemini, Radox AI, ya OpenAI API key daalein.');
   if(intent)showDynamicActions();
   return;
  }
  const d=await api('chat',{
   message,
   history:chatHistory.slice(0,-1),
   projectState:{
    appName:$('appName').value,
    packageId:$('packageId').value,
    zipSelected:Boolean(selectedFile||generatedProjectReady),
    individualFiles:selectedSources.length,
    githubConfigured:Boolean((credentials().owner&&credentials().repo&&credentials().token)||vaultState.githubConfigured),
    latestRun
   }
  });
  const badge=d.fallback
   ?`[Automatic Failover: ${providerLabel(d.fallback.from)} → ${providerLabel(d.fallback.to)}]\n`
   :`[AI: ${providerLabel(d.usedProvider||activeAIProvider)}]\n`;
  $('topProviderBadge').textContent=providerLabel(d.usedProvider||activeAIProvider);
  addChat('agent',badge+d.reply);
  chatHistory.push({role:'model',text:d.reply});
  if(intent||/apk|aab|build|project|upload|fix|download/i.test(d.reply))showDynamicActions();
 }catch(e){
  addChat('agent','AI request fail hui: '+e.message+' (Settings mein apni Primary/Backup API key aur model check karein).');
 }
}

function readText(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=()=>reject(Error('Could not read '+file.name));r.readAsText(file)})}
function fileToBase64(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('File read failed'));reader.readAsDataURL(file)})}

async function startBuild(){
 if(!selectedFile&&!selectedSources.length&&!generatedProjectReady){
  await generateAndroidProjectFromChat();
  if(!generatedProjectReady)return;
 }
 const c=credentials();
 if((!c.owner||!c.repo||!c.token)&&!vaultState.githubConfigured){
  toggleDrawer(true);
  return addChat('agent','Real APK/AAB compile karne ke liye Settings -> GitHub Cloud Build Agent mein Owner, Repository aur Token connect karein.');
 }
 if(!/^[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)+$/.test($('packageId').value.trim())){
  return addChat('agent','Package ID format sahi nahi hai. Example: com.appbuild.videoplayer');
 }

 $('buildBtn').disabled=true;
 $('progressArea').innerHTML=`
  <div class="progress-card">
   <div class="progress-head"><span>${escapeHtml($('appName').value)} — Isolated Cloud Build चल रहा है…</span><span id="progPct">15%</span></div>
   <div class="progress-track"><div class="progress-fill" id="progFill" style="width:15%"></div></div>
  </div>`;
 addChat('agent','Theek hai! Main aapka Android project isolated GitHub cloud runner par bhej raha hoon. Wahan Gradle APK aur Signed Play Store AAB compile ho raha hai...');
 log('Uploading isolated workspace to GitHub...');

 try{
  let d;
  if(selectedFile){
   const base64=await fileToBase64(selectedFile);
   d=await api('build',{fileName:selectedFile.name,base64,appName:$('appName').value,packageId:$('packageId').value,versionCode:$('versionCode').value,obfuscate:$('obfuscate').checked});
  } else if(selectedSources.length){
   const packed=[];
   for(const f of selectedSources){
    const base64=await fileToBase64(f);
    packed.push({path:f.webkitRelativePath||f.name,base64});
   }
   d=await api('build-files',{files:packed,appName:$('appName').value,packageId:$('packageId').value,versionCode:$('versionCode').value,obfuscate:$('obfuscate').checked});
  } else {
   d=await api('build',{appName:$('appName').value,packageId:$('packageId').value,versionCode:$('versionCode').value,obfuscate:$('obfuscate').checked});
  }
  currentBuildId=d.buildId||null;
  currentWorkspacePath=d.workspacePath||'project.zip';
  $('status').textContent=d.message;
  log(d.message);
  pollRuns();
 }catch(e){
  $('status').textContent='Build request failed: '+e.message;
  $('buildBtn').disabled=false;
  addChat('agent','Build request fail hua: '+e.message);
 }
}

async function pollRuns(){
 let attempts=0;
 clearInterval(pollTimer);
 pollTimer=setInterval(async()=>{
  attempts++;
  try{
   const d=await api('runs',{buildId:currentBuildId});
   const run=d.runs[0];
   if(!run)return;
   if(run.id!==latestRun){
    latestRun=run.id;
    log('GitHub Actions run #'+run.id+' · '+run.status);
   }
   const pct=run.status==='completed'?100:(run.status==='in_progress'?68:32);
   if($('progFill'))$('progFill').style.width=pct+'%';
   if($('progPct'))$('progPct').textContent=pct+'%';
   $('status').textContent='GitHub Actions: '+run.status+(run.conclusion?' / '+run.conclusion:'');

   if(run.status==='completed'){
    clearInterval(pollTimer);
    $('buildBtn').disabled=false;
    log('Workflow completed: '+run.conclusion);
    if(run.conclusion==='success'){
     addChat('agent','✅ Aapka APK aur Signed Play Store AAB tayyar hai! Neeche Download button se seedha installable APK ya AAB download karein.');
     loadArtifacts(run.id);
    }else{
     addChat('agent','Build fail hua ('+run.conclusion+'). Main actual Gradle build logs inspect karke auto-fix karne ke liye Repair panel khol raha hoon.');
     failedRunId=run.id;
     $('repairPanel').classList.remove('hidden');
    }
   }
  }catch(e){log('Polling: '+e.message)}
  if(attempts>120){
   clearInterval(pollTimer);
   $('buildBtn').disabled=false;
   $('status').textContent='Polling timeout. Check GitHub Actions tab.';
  }
 },8000);
}

async function loadArtifacts(runId){
 try{
  const d=await api('artifacts',{runId});
  $('outputs').innerHTML='';
  $('outputs').classList.remove('hidden');
  if(!d.artifacts.length){
   $('outputs').textContent='No artifacts found on workflow run.';
   return;
  }
  d.artifacts.forEach(a=>{
   const el=document.createElement('div');
   el.className='download-card';
   const sizeMb=(a.size/1024/1024).toFixed(2)+' MB';
   el.innerHTML=`
    <div class="download-icon">APK</div>
    <div class="download-name">
     <b>${escapeHtml($('appName').value.replace(/\s+/g,'-')||a.name)}-v1.0.0.apk</b>
     <small>Verified Build · Size: ${sizeMb}</small>
    </div>
    <button class="download-btn" onclick="downloadArtifact(${a.id},'apk')">⬇ Download APK</button>
    <button class="download-btn secondary" onclick="downloadArtifact(${a.id},'aab')">⬇ Signed AAB</button>
   `;
   $('outputs').append(el);
  });
  $(' outputs')?.scrollIntoView({behavior:'smooth'});
  log('Verified APK & Signed AAB artifacts ready.');
 }catch(e){$('outputs').textContent=e.message}
}

async function downloadArtifact(id,format='apk'){
 try{
  const r=await fetch('/api/artifact-download',{
   method:'POST',
   headers:{'Content-Type':'application/json'},
   body:JSON.stringify({...credentials(),artifactId:id,format})
  });
  if(!r.ok){
   const d=await r.json().catch(()=>({}));
   throw Error(d.error||'Download failed');
  }
  const blob=await r.blob();
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  const cleanName=($('appName').value.trim().replace(/[^a-zA-Z0-9_-]/g,'')||'AppBuild')+'-v1.0.0';
  a.download=format==='aab'?`${cleanName}-PlayStore-Signed.aab`:(format==='apk'?`${cleanName}.apk`:`${cleanName}-artifacts.zip`);
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
 }catch(e){addChat('agent','Download error: '+e.message)}
}

async function diagnoseFailure(){
 if(!hasAnyAiConfigured())return addChat('agent','Selected AI provider ki API key Settings mein add karein.');
 if(!failedRunId)return;
 $('repairProposal').textContent='GitHub Actions Gradle logs download aur AI diagnosis chal raha hai...';
 $('approveFixBtn').classList.add('hidden');
 try{
  const d=await api('diagnose-run',{runId:failedRunId,workspacePath:currentWorkspacePath});
  pendingFixes=d.proposal.fixes||[];
  const usedInfo=d.fallback?`[Failover: ${d.fallback.from} → ${d.fallback.to}]`:`[AI: ${d.usedProvider}]`;
  let t=`${usedInfo}\nSUMMARY: ${d.proposal.summary||''}\nROOT CAUSE: ${d.proposal.root_cause||''}\nCONFIDENCE: ${d.proposal.confidence||'high'}\n\n`;
  if(pendingFixes.length){
   t+='PROPOSED FILE FIXES:\n'+pendingFixes.map(f=>'- '+f.path+': '+f.reason).join('\n');
   $('approveFixBtn').classList.remove('hidden');
  }else{
   t+='MANUAL STEPS:\n'+(d.proposal.manual_steps||[]).join('\n');
  }
  $('repairProposal').textContent=t;
 }catch(e){$('repairProposal').textContent='Diagnosis failed: '+e.message}
}

async function approveFixes(){
 if(!pendingFixes.length)return;
 $('approveFixBtn').disabled=true;
 try{
  const d=await api('approve-fixes-rerun',{
   fixes:pendingFixes,
   workspacePath:currentWorkspacePath,
   appName:$('appName').value,
   packageId:$('packageId').value,
   versionCode:$('versionCode').value,
   obfuscate:$('obfuscate').checked
  });
  currentBuildId=d.buildId||currentBuildId;
  currentWorkspacePath=d.workspacePath||currentWorkspacePath;
  $('status').textContent=d.message;
  pendingFixes=[];
  $('approveFixBtn').classList.add('hidden');
  pollRuns();
 }catch(e){addChat('agent','Fix apply nahi hua: '+e.message)}
 finally{$('approveFixBtn').disabled=false}
}

function downloadWorkflow(){
 const a=document.createElement('a');
 a.href='/agent-builder.yml';
 a.download='agent-builder.yml';
 a.click();
}
