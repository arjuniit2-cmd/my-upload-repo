const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const AdmZip = require("adm-zip");

let Pool = null;
try {
  Pool = require("pg").Pool;
} catch {
  Pool = null;
}

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "180mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 90, standardHeaders: true, legacyHeaders: false }));

// ============================================================================
// 1. AES-256-GCM SERVER-SIDE ENCRYPTED CREDENTIAL VAULT & PERSISTENT DATABASE
// ============================================================================
const DATA_DIR = path.join(__dirname, ".data");
const KEY_FILE = path.join(DATA_DIR, "master.key");
const DB_FILE = path.join(DATA_DIR, "appbuild_db.json");

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  }
}

function getMasterKey() {
  ensureDataDir();
  if (process.env.APP_MASTER_SECRET && process.env.APP_MASTER_SECRET.trim().length >= 16) {
    return crypto.createHash("sha256").update(process.env.APP_MASTER_SECRET.trim()).digest();
  }
  if (fs.existsSync(KEY_FILE)) {
    return Buffer.from(fs.readFileSync(KEY_FILE, "utf8").trim(), "hex");
  }
  const generated = crypto.randomBytes(32);
  fs.writeFileSync(KEY_FILE, generated.toString("hex"), { mode: 0o600 });
  return generated;
}

const MASTER_KEY = getMasterKey();

function encryptSecret(plainText) {
  if (!plainText || !String(plainText).trim()) return "";
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", MASTER_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(String(plainText).trim(), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("hex")}:${tag.toString("hex")}:${encrypted.toString("hex")}`;
}

function decryptSecret(cipherText) {
  if (!cipherText) return "";
  try {
    const parts = String(cipherText).split(":");
    if (parts.length !== 3) return "";
    const [ivHex, tagHex, encHex] = parts;
    const decipher = crypto.createDecipheriv("aes-256-gcm", MASTER_KEY, Buffer.from(ivHex, "hex"));
    decipher.setAuthTag(Buffer.from(tagHex, "hex"));
    const decrypted = Buffer.concat([decipher.update(Buffer.from(encHex, "hex")), decipher.final()]);
    return decrypted.toString("utf8");
  } catch {
    return "";
  }
}

function maskSecret(s) {
  if (!s || s.length < 8) return s ? "••••••••" : "";
  return `${s.slice(0, 4)}••••${s.slice(-4)}`;
}

// Persistent Multi-User Database (PostgreSQL + Atomic Local File Fallback)
const dbState = {
  users: {},       // userId -> { id, createdAt, encryptedCreds, preferences }
  projects: {},    // `${userId}:${projectId}` -> { id, userId, appName, packageId, files, checkpoints, updatedAt }
  builds: {},      // `${userId}:${buildId}` -> { id, userId, projectId, workspacePath, runId, status, createdAt }
  signingKeys: {}  // `${userId}:${packageId}` -> { alias, encryptedPassword }
};

let pgPool = null;
async function initDatabase() {
  ensureDataDir();
  if (process.env.DATABASE_URL && Pool) {
    try {
      pgPool = new Pool({
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.DATABASE_SSL === "false" ? false : { rejectUnauthorized: false }
      });
      await pgPool.query(`
        CREATE TABLE IF NOT EXISTS appbuild_kv (
          collection VARCHAR(64) NOT NULL,
          item_key VARCHAR(255) NOT NULL,
          user_id VARCHAR(128),
          payload JSONB NOT NULL,
          updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
          PRIMARY KEY (collection, item_key)
        );
      `);
      const res = await pgPool.query("SELECT collection, item_key, payload FROM appbuild_kv");
      for (const row of res.rows) {
        if (dbState[row.collection]) {
          dbState[row.collection][row.item_key] = row.payload;
        }
      }
      console.log("[AppBuild] Connected to PostgreSQL persistence.");
      return;
    } catch (err) {
      console.warn("[AppBuild] PostgreSQL unavailable, using persistent local database:", err.message);
      pgPool = null;
    }
  }
  if (fs.existsSync(DB_FILE)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
      Object.assign(dbState, parsed);
    } catch (e) {
      console.warn("[AppBuild] Local DB load warning:", e.message);
    }
  }
}

async function saveDbRecord(collection, key, userId, value) {
  if (!dbState[collection]) dbState[collection] = {};
  if (value === null || value === undefined) {
    delete dbState[collection][key];
  } else {
    dbState[collection][key] = value;
  }
  if (pgPool) {
    try {
      if (value === null || value === undefined) {
        await pgPool.query("DELETE FROM appbuild_kv WHERE collection=$1 AND item_key=$2", [collection, key]);
      } else {
        await pgPool.query(
          `INSERT INTO appbuild_kv (collection, item_key, user_id, payload, updated_at)
           VALUES ($1, $2, $3, $4::jsonb, NOW())
           ON CONFLICT (collection, item_key)
           DO UPDATE SET payload=EXCLUDED.payload, updated_at=NOW()`,
          [collection, key, userId, JSON.stringify(value)]
        );
      }
      return;
    } catch (e) {
      console.error("[AppBuild] PG write error:", e.message);
    }
  }
  ensureDataDir();
  const tmp = `${DB_FILE}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(dbState, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DB_FILE);
}

// ============================================================================
// 2. MULTI-USER SESSION ISOLATION & AUTOMATIC CREDENTIAL VAULT RESOLUTION
// ============================================================================
function parseCookies(req) {
  const header = req.headers.cookie || "";
  const out = {};
  header.split(";").forEach(pair => {
    const idx = pair.indexOf("=");
    if (idx > 0) {
      const k = pair.slice(0, idx).trim();
      const v = pair.slice(idx + 1).trim();
      out[k] = decodeURIComponent(v);
    }
  });
  return out;
}

function signUserToken(userId) {
  const mac = crypto.createHmac("sha256", MASTER_KEY).update(userId).digest("hex").slice(0, 32);
  return `${userId}.${mac}`;
}

function verifyUserToken(raw) {
  if (!raw || typeof raw !== "string" || !raw.includes(".")) return null;
  const [userId, mac] = raw.split(".");
  if (!/^usr_[a-zA-Z0-9_-]{8,48}$/.test(userId)) return null;
  const expected = crypto.createHmac("sha256", MASTER_KEY).update(userId).digest("hex").slice(0, 32);
  if (mac !== expected) return null;
  return userId;
}

app.use((req, res, next) => {
  const cookies = parseCookies(req);
  const headerToken = req.headers["x-appbuild-session"] || req.body?.sessionToken || cookies.appbuild_session;
  let userId = verifyUserToken(headerToken);
  if (!userId) {
    userId = `usr_${crypto.randomBytes(10).toString("hex")}`;
    const signed = signUserToken(userId);
    res.setHeader("Set-Cookie", `appbuild_session=${encodeURIComponent(signed)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000`);
    req.generatedSessionToken = signed;
  } else {
    req.generatedSessionToken = headerToken;
  }
  req.userId = userId;
  if (!dbState.users[userId]) {
    dbState.users[userId] = {
      id: userId,
      createdAt: new Date().toISOString(),
      encryptedCreds: {},
      preferences: {
        provider: "gemini",
        fallbackProvider: "radox",
        tertiaryProvider: "openai",
        geminiModel: "gemini-2.5-flash",
        radoxModel: "",
        radoxBaseUrl: process.env.DEFAULT_RADOX_BASE_URL || "https://radoxai.com/v1",
        openaiModel: "gpt-4o-mini"
      }
    };
  }
  next();
});

async function resolveAndSyncUserContext(req) {
  const user = dbState.users[req.userId];
  const body = req.body || {};
  const enc = user.encryptedCreds || {};
  const prefs = user.preferences || {};
  let dirty = false;

  // Save incoming non-empty keys encrypted into server vault
  for (const field of ["geminiKey", "radoxKey", "openaiKey", "token"]) {
    if (typeof body[field] === "string" && body[field].trim() && !body[field].includes("••••")) {
      enc[field] = encryptSecret(body[field].trim());
      dirty = true;
    }
  }
  for (const metaField of ["owner", "repo", "provider", "fallbackProvider", "tertiaryProvider", "geminiModel", "radoxModel", "radoxBaseUrl", "openaiModel"]) {
    if (typeof body[metaField] === "string" && body[metaField].trim()) {
      prefs[metaField] = body[metaField].trim();
      dirty = true;
    }
  }

  if (dirty) {
    user.encryptedCreds = enc;
    user.preferences = prefs;
    await saveDbRecord("users", req.userId, req.userId, user);
  }

  return {
    userId: req.userId,
    provider: body.provider || prefs.provider || "gemini",
    fallbackProvider: body.fallbackProvider || prefs.fallbackProvider || "radox",
    tertiaryProvider: body.tertiaryProvider || prefs.tertiaryProvider || "openai",
    geminiKey: (body.geminiKey && !body.geminiKey.includes("••••") ? body.geminiKey.trim() : "") || decryptSecret(enc.geminiKey),
    geminiModel: body.geminiModel || prefs.geminiModel || "gemini-2.5-flash",
    radoxKey: (body.radoxKey && !body.radoxKey.includes("••••") ? body.radoxKey.trim() : "") || decryptSecret(enc.radoxKey),
    radoxModel: body.radoxModel || body.model || prefs.radoxModel || "",
    radoxBaseUrl: (body.radoxBaseUrl || prefs.radoxBaseUrl || process.env.DEFAULT_RADOX_BASE_URL || "https://radoxai.com/v1").replace(/\/+$/, ""),
    openaiKey: (body.openaiKey && !body.openaiKey.includes("••••") ? body.openaiKey.trim() : "") || decryptSecret(enc.openaiKey),
    openaiModel: body.openaiModel || prefs.openaiModel || "gpt-4o-mini",
    owner: body.owner || prefs.owner || "",
    repo: body.repo || prefs.repo || "",
    token: (body.token && !body.token.includes("••••") ? body.token.trim() : "") || decryptSecret(enc.token)
  };
}

// Settings Restore & Key Management Endpoints
app.get("/api/session", async (req, res) => {
  const user = dbState.users[req.userId];
  const enc = user.encryptedCreds || {};
  const prefs = user.preferences || {};
  const gKey = decryptSecret(enc.geminiKey);
  const rKey = decryptSecret(enc.radoxKey);
  const oKey = decryptSecret(enc.openaiKey);
  const ghToken = decryptSecret(enc.token);

  res.json({
    ok: true,
    userId: req.userId,
    sessionToken: req.generatedSessionToken,
    saved: {
      geminiConfigured: Boolean(gKey),
      geminiMasked: maskSecret(gKey),
      geminiModel: prefs.geminiModel || "gemini-2.5-flash",
      radoxConfigured: Boolean(rKey),
      radoxMasked: maskSecret(rKey),
      radoxModel: prefs.radoxModel || "",
      radoxBaseUrl: prefs.radoxBaseUrl || "https://radoxai.com/v1",
      openaiConfigured: Boolean(oKey),
      openaiMasked: maskSecret(oKey),
      openaiModel: prefs.openaiModel || "gpt-4o-mini",
      provider: prefs.provider || "gemini",
      fallbackProvider: prefs.fallbackProvider || "radox",
      tertiaryProvider: prefs.tertiaryProvider || "openai",
      owner: prefs.owner || "",
      repo: prefs.repo || "",
      githubConfigured: Boolean(ghToken && prefs.owner && prefs.repo),
      githubMasked: maskSecret(ghToken)
    }
  });
});

app.post("/api/remove-credential", async (req, res) => {
  try {
    const { target } = req.body || {};
    const user = dbState.users[req.userId];
    if (!user) return res.json({ ok: true });
    if (target === "gemini") delete user.encryptedCreds.geminiKey;
    if (target === "radox") delete user.encryptedCreds.radoxKey;
    if (target === "openai") delete user.encryptedCreds.openaiKey;
    if (target === "github") {
      delete user.encryptedCreds.token;
      user.preferences.owner = "";
      user.preferences.repo = "";
    }
    await saveDbRecord("users", req.userId, req.userId, user);
    res.json({ ok: true, removed: target });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// ============================================================================
// 3. AI PROVIDERS (GEMINI, RADOX AI, OPENAI) + STRICT CONNECTION TESTS
// ============================================================================
function providerError(message, status, provider) {
  const e = new Error(message || `${provider} API error`);
  e.status = Number(status || 0);
  e.provider = provider;
  return e;
}

async function fetchGeminiModels(apiKey) {
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    throw providerError(data.error?.message || `Gemini API error ${r.status}`, r.status, "gemini");
  }
  const models = (data.models || [])
    .filter(m => Array.isArray(m.supportedGenerationMethods) && m.supportedGenerationMethods.includes("generateContent"))
    .map(m => ({
      id: m.name.replace(/^models\//, ""),
      displayName: m.displayName || m.name.replace(/^models\//, "")
    }));
  return models;
}

async function geminiText(apiKey, prompt, requestedModel = "gemini-2.5-flash") {
  if (!apiKey) throw providerError("Gemini API key required hai.", 401, "gemini");
  const candidateModels = [
    requestedModel ? requestedModel.replace(/^models\//, "") : "gemini-2.5-flash",
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-flash"
  ].filter((v, i, a) => v && a.indexOf(v) === i);

  let lastErr = null;
  for (const modelId of candidateModels) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(modelId)}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const r = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.2 }
      })
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      const err = providerError(data.error?.message || data.message || `Gemini API error ${r.status}`, r.status, "gemini");
      // If 404 (model ID not found on this key tier), try next verified Gemini model
      if (r.status === 404) {
        lastErr = err;
        continue;
      }
      throw err;
    }
    const outputText = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "";
    if (!outputText.trim()) {
      throw providerError("Gemini ne empty response diya.", 502, "gemini");
    }
    return { text: outputText, modelUsed: modelId };
  }
  throw lastErr || providerError("Gemini model unavailable.", 404, "gemini");
}

async function fetchRadoxModels(apiKey, baseUrl = "https://radoxai.com/v1") {
  const cleanBase = (baseUrl || "https://radoxai.com/v1").replace(/\/+$/, "");
  const r = await fetch(`${cleanBase}/models`, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "x-api-key": apiKey
    }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    throw providerError(data.error?.message || data.message || `Radox models error ${r.status}`, r.status, "radox");
  }
  const rawList = Array.isArray(data.data) ? data.data : Array.isArray(data.models) ? data.models : [];
  return rawList
    .map(m => (typeof m === "string" ? { id: m, name: m } : { id: m.id || m.name, name: m.name || m.id, capabilities: m.capabilities || [] }))
    .filter(m => Boolean(m.id));
}

async function radoxText(apiKey, prompt, requestedModel = "", baseUrl = "https://radoxai.com/v1") {
  if (!apiKey) throw providerError("Radox AI API key required hai.", 401, "radox");
  const cleanBase = (baseUrl || "https://radoxai.com/v1").replace(/\/+$/, "");
  let modelToUse = (requestedModel || "").trim();

  // Dynamically discover available Radox model if none selected or if default fails
  if (!modelToUse) {
    try {
      const available = await fetchRadoxModels(apiKey, cleanBase);
      if (available.length > 0) modelToUse = available[0].id;
    } catch {
      modelToUse = "deepseek-v4-flash-0731";
    }
  }

  const attemptCompletion = async (mdl) => {
    const r = await fetch(`${cleanBase}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
        "x-api-key": apiKey
      },
      body: JSON.stringify({
        model: mdl,
        messages: [{ role: "user", content: prompt }],
        temperature: 0.2
      })
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      throw providerError(data.error?.message || data.message || `Radox AI API error ${r.status}`, r.status, "radox");
    }
    const out = data.choices?.[0]?.message?.content || data.output_text || "";
    if (typeof out !== "string" || !out.trim()) {
      throw providerError("Radox AI ne text response nahi diya.", 502, "radox");
    }
    return { text: out, modelUsed: mdl };
  };

  try {
    return await attemptCompletion(modelToUse || "deepseek-v4-flash-0731");
  } catch (err) {
    // If model was invalid/unavailable (400/404), auto-discover first valid model from /models
    if (err.status === 404 || err.status === 400) {
      const models = await fetchRadoxModels(apiKey, cleanBase).catch(() => []);
      if (models.length && models[0].id !== modelToUse) {
        return await attemptCompletion(models[0].id);
      }
    }
    throw err;
  }
}

async function fetchOpenAIModels(apiKey) {
  const r = await fetch("https://api.openai.com/v1/models", {
    headers: { Authorization: `Bearer ${apiKey}` }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    throw providerError(data.error?.message || `OpenAI models error ${r.status}`, r.status, "openai");
  }
  return (data.data || [])
    .filter(m => /^(gpt-|o1|o3|o4|chatgpt-)/i.test(m.id))
    .map(m => ({ id: m.id, created: m.created, owned_by: m.owned_by }))
    .sort((a, b) => a.id.localeCompare(b.id));
}

async function openaiText(apiKey, prompt, requestedModel = "gpt-4o-mini") {
  if (!apiKey) throw providerError("OpenAI API key required hai.", 401, "openai");
  let model = (requestedModel || "").trim() || "gpt-4o-mini";

  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model,
      messages: [{ role: "user", content: prompt }],
      temperature: 0.2
    })
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    throw providerError(data.error?.message || `OpenAI API error ${r.status}`, r.status, "openai");
  }
  const out = data.choices?.[0]?.message?.content || "";
  if (!out.trim()) {
    throw providerError("OpenAI ne text response nahi diya.", 502, "openai");
  }
  return { text: out, modelUsed: model };
}

// STRICT Provider-Specific Connection Tests (NEVER uses fallback!)
app.post("/api/test-gemini", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    if (!ctx.geminiKey) throw new Error("Gemini API key required hai.");
    const models = await fetchGeminiModels(ctx.geminiKey);
    const preferred = ctx.geminiModel || (models[0]?.id) || "gemini-2.5-flash";
    const out = await geminiText(ctx.geminiKey, "Reply with exactly: Gemini connection successful.", preferred);
    res.json({
      ok: true,
      provider: "gemini",
      model: out.modelUsed,
      models,
      response: out.text.slice(0, 100)
    });
  } catch (e) {
    res.status(400).json({ ok: false, provider: "gemini", error: e.message });
  }
});

app.post("/api/gemini-models", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    if (!ctx.geminiKey) throw new Error("Gemini API key required hai.");
    const models = await fetchGeminiModels(ctx.geminiKey);
    res.json({ ok: true, models });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.post("/api/test-radox", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    if (!ctx.radoxKey) throw new Error("Radox AI API key required hai.");
    const out = await radoxText(ctx.radoxKey, "Reply with exactly: Radox connection successful.", ctx.radoxModel, ctx.radoxBaseUrl);
    const models = await fetchRadoxModels(ctx.radoxKey, ctx.radoxBaseUrl).catch(() => [{ id: out.modelUsed, name: out.modelUsed }]);
    res.json({
      ok: true,
      provider: "radox",
      model: out.modelUsed,
      models,
      response: out.text.slice(0, 100)
    });
  } catch (e) {
    res.status(400).json({ ok: false, provider: "radox", error: e.message });
  }
});

app.post("/api/radox-models", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    if (!ctx.radoxKey) throw new Error("Radox AI API key required hai.");
    const models = await fetchRadoxModels(ctx.radoxKey, ctx.radoxBaseUrl);
    res.json({ ok: true, models });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.post("/api/test-openai", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    if (!ctx.openaiKey) throw new Error("OpenAI API key required hai.");
    const out = await openaiText(ctx.openaiKey, "Reply with exactly: OpenAI connection successful.", ctx.openaiModel || "gpt-4o-mini");
    const models = await fetchOpenAIModels(ctx.openaiKey).catch(() => [{ id: out.modelUsed }]);
    res.json({
      ok: true,
      provider: "openai",
      model: out.modelUsed,
      models,
      response: out.text.slice(0, 100)
    });
  } catch (e) {
    res.status(400).json({ ok: false, provider: "openai", error: e.message });
  }
});

app.post("/api/openai-models", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    if (!ctx.openaiKey) throw new Error("OpenAI API key required hai.");
    const models = await fetchOpenAIModels(ctx.openaiKey);
    res.json({ ok: true, models });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// ============================================================================
// 4. PRIMARY AI + STATEFUL CHECKPOINT AUTOMATIC FAILOVER ENGINE
// ============================================================================
function isFailoverWorthy(err) {
  const status = Number(err.status || 0);
  // HTTP 429 (Quota/Rate limit), 500/502/503/504 (Outage), 408 (Timeout)
  // NEVER failover on 401 (Invalid Key) or 403 (Permission Denied)
  if ([408, 409, 425, 429, 500, 502, 503, 504].includes(status)) return true;
  if (status === 0 && /fetch failed|network|timeout|socket|ECONNRESET|ENOTFOUND|ETIMEDOUT/i.test(err.message || "")) return true;
  return false;
}

async function callSingleProvider(providerName, ctx, prompt) {
  if (providerName === "gemini") {
    if (!ctx.geminiKey) throw providerError("Gemini API key missing hai.", 401, "gemini");
    return await geminiText(ctx.geminiKey, prompt, ctx.geminiModel);
  }
  if (providerName === "radox") {
    if (!ctx.radoxKey) throw providerError("Radox AI API key missing hai.", 401, "radox");
    return await radoxText(ctx.radoxKey, prompt, ctx.radoxModel, ctx.radoxBaseUrl);
  }
  if (providerName === "openai") {
    if (!ctx.openaiKey) throw providerError("OpenAI API key missing hai.", 401, "openai");
    return await openaiText(ctx.openaiKey, prompt, ctx.openaiModel);
  }
  throw providerError(`Unknown AI provider: ${providerName}`, 400, providerName);
}

/**
 * Stateful Failover Agent:
 * - Tries Primary Provider (with 1 transient retry on 503/timeout).
 * - If HTTP 429 (Quota) or 503 (Outage) occurs, automatically switches to Backup Provider, then Tertiary Provider.
 * - Injects the active project checkpoint into the prompt so the backup provider continues seamlessly without restarting.
 */
async function aiTextWithCheckpoint(ctx, prompt, checkpointState = null) {
  const chain = [ctx.provider || "gemini"];
  if (ctx.fallbackProvider && ctx.fallbackProvider !== "none" && !chain.includes(ctx.fallbackProvider)) {
    chain.push(ctx.fallbackProvider);
  }
  for (const extra of ["radox", "openai", "gemini"]) {
    if (!chain.includes(extra)) {
      const hasKey = (extra === "gemini" && ctx.geminiKey) || (extra === "radox" && ctx.radoxKey) || (extra === "openai" && ctx.openaiKey);
      if (hasKey && ctx.fallbackProvider !== "none") chain.push(extra);
    }
  }

  let primaryErr = null;
  for (let i = 0; i < chain.length; i++) {
    const currentProvider = chain[i];
    const isBackup = i > 0;

    const contextualPrompt = isBackup && checkpointState
      ? `[AUTOMATIC FAILOVER RESUME — DO NOT RESTART THE PROJECT. Continue from this exact checkpoint state]:\n${JSON.stringify(checkpointState)}\n\nTask:\n${prompt}`
      : prompt;

    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await callSingleProvider(currentProvider, ctx, contextualPrompt);
        return {
          text: res.text,
          usedProvider: currentProvider,
          usedModel: res.modelUsed,
          fallback: isBackup && primaryErr
            ? { from: chain[0], to: currentProvider, reason: primaryErr.message, checkpointPreserved: true }
            : null
        };
      } catch (err) {
        if (attempt === 0 && [502, 503, 504, 408].includes(Number(err.status))) {
          await new Promise(r => setTimeout(r, 900));
          continue;
        }
        if (i === 0) primaryErr = err;
        // Do NOT failover on 401/403 authentication errors on the primary provider
        if (!isFailoverWorthy(err)) {
          throw err;
        }
        break; // Move to backup provider in chain
      }
    }
  }
  throw primaryErr || new Error("Configured AI providers failed.");
}

// ============================================================================
// 5. NATIVE ANDROID GRADLE PROJECT GENERATOR AGENT (FROM NATURAL LANGUAGE)
// ============================================================================
function sanitizePackageId(raw, appName = "myapp") {
  const cleaned = String(raw || "")
    .toLowerCase()
    .replace(/[^a-z0-9.]/g, "")
    .replace(/\.{2,}/g, ".")
    .replace(/^\.|\.$/g, "");
  if (/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){2,}$/.test(cleaned)) return cleaned;
  const slug = String(appName || "myapp").toLowerCase().replace(/[^a-z0-9]/g, "") || "myapp";
  return `com.appbuild.${slug}`;
}

function buildCompleteAndroidGradleTree({ appName, packageId, versionCode = "1", aiCustomFiles = {} }) {
  const safeName = String(appName || "AppBuild App").replace(/[<>&"']/g, "").trim() || "AppBuild App";
  const safePkg = sanitizePackageId(packageId, safeName);
  const pkgPath = safePkg.replace(/\./g, "/");
  const verCode = Number(versionCode) > 0 ? Number(versionCode) : 1;

  const baseFiles = {
    "settings.gradle.kts": `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "${safeName.replace(/[^a-zA-Z0-9_-]/g, "") || "AppBuildApp"}"
include(":app")
`,
    "build.gradle.kts": `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
`,
    "gradle.properties": `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`,
    "gradle/wrapper/gradle-wrapper.properties": `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`,
    "app/proguard-rules.pro": `-keepattributes *Annotation*\n`,
    "app/build.gradle.kts": `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${safePkg}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${safePkg}"
        minSdk = 24
        targetSdk = 34
        versionCode = ${verCode}
        versionName = "1.0.${verCode}"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
}
`,
    "app/src/main/AndroidManifest.xml": `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:allowBackup="true"
        android:label="${safeName}"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`,
    "app/src/main/res/values/strings.xml": `<resources>
    <string name="app_name">${safeName}</string>
</resources>
`,
    [`app/src/main/java/${pkgPath}/MainActivity.kt`]: `package ${safePkg}

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
`,
    "app/src/main/res/layout/activity_main.xml": `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:gravity="center"
    android:padding="24dp"
    android:background="#FFFFFF">

    <TextView
        android:id="@+id/headerTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="${safeName}"
        android:textColor="#111318"
        android:textSize="24sp"
        android:textStyle="bold" />

    <TextView
        android:id="@+id/subTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="12dp"
        android:text="Built with App Build AI"
        android:textColor="#667085"
        android:textSize="15sp" />
</LinearLayout>
`
  };

  for (const [relPath, content] of Object.entries(aiCustomFiles || {})) {
    const clean = String(relPath).replace(/\\/g, "/").replace(/^\/+/, "");
    if (!clean || clean.includes("..") || typeof content !== "string" || !content.trim()) continue;
    baseFiles[clean] = content;
  }

  return { appName: safeName, packageId: safePkg, files: baseFiles };
}

// Endpoint: AI generates a complete native Android project directly from chat requirements!
app.post("/api/generate-project", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const { idea, appName, packageId, versionCode = "1", projectId = "default" } = req.body || {};
    if (!idea) throw new Error("App ka idea ya requirement batayein.");

    const projKey = `${ctx.userId}:${projectId}`;
    const existingProj = dbState.projects[projKey] || {
      id: projectId,
      userId: ctx.userId,
      appName: appName || "My Android App",
      packageId: sanitizePackageId(packageId, appName || "myapp"),
      files: {},
      checkpoints: []
    };

    const targetAppName = appName || existingProj.appName || "Smart Android App";
    const targetPkg = sanitizePackageId(packageId || existingProj.packageId, targetAppName);
    const pkgPath = targetPkg.replace(/\./g, "/");

    const genPrompt = `You are a Senior Native Android Engineer (Kotlin + XML, compileSdk 34, Material3).
Generate a complete, working, self-contained Android MainActivity.kt and activity_main.xml for the following app idea:
App Idea: "${idea}"
App Name: "${targetAppName}"
Package ID: "${targetPkg}"

STRICT RULES:
1. Return ONLY valid JSON with shape:
{
  "appName": "${targetAppName}",
  "packageId": "${targetPkg}",
  "summaryHinglish": "Short Hinglish summary of features generated",
  "mainActivityKt": "Complete compilable Kotlin code starting with package ${targetPkg} ...",
  "activityMainXml": "Complete valid Android XML layout starting with <?xml version=\\"1.0\\" encoding=\\"utf-8\\"?> ..."
}
2. Only use standard Android SDK + AndroidX AppCompat + Material3 views/widgets so it compiles 100% without missing third-party libraries.
3. Make the UI functional and interactive (buttons, click listeners, state updates, lists/inputs as needed).`;

    const aiRes = await aiTextWithCheckpoint(ctx, genPrompt, {
      stage: "android_code_generation",
      appName: targetAppName,
      packageId: targetPkg,
      existingFileCount: Object.keys(existingProj.files || {}).length
    });

    let parsed = {};
    try {
      const m = aiRes.text.match(/\{[\s\S]*\}/);
      if (m) parsed = JSON.parse(m[0]);
    } catch {
      parsed = {};
    }

    const customFiles = { ...(existingProj.files || {}) };
    if (parsed.mainActivityKt && parsed.mainActivityKt.includes("class MainActivity")) {
      customFiles[`app/src/main/java/${pkgPath}/MainActivity.kt`] = parsed.mainActivityKt;
    }
    if (parsed.activityMainXml && parsed.activityMainXml.includes("<")) {
      customFiles["app/src/main/res/layout/activity_main.xml"] = parsed.activityMainXml;
    }

    const fullProject = buildCompleteAndroidGradleTree({
      appName: parsed.appName || targetAppName,
      packageId: targetPkg,
      versionCode,
      aiCustomFiles: customFiles
    });

    const zip = new AdmZip();
    for (const [fPath, fContent] of Object.entries(fullProject.files)) {
      zip.addFile(fPath, Buffer.from(fContent, "utf8"));
    }
    const zipBase64 = zip.toBuffer().toString("base64");

    existingProj.appName = fullProject.appName;
    existingProj.packageId = fullProject.packageId;
    existingProj.files = fullProject.files;
    existingProj.zipBase64 = zipBase64;
    existingProj.updatedAt = new Date().toISOString();
    existingProj.checkpoints.push({
      at: existingProj.updatedAt,
      provider: aiRes.usedProvider,
      fileCount: Object.keys(fullProject.files).length
    });

    await saveDbRecord("projects", projKey, ctx.userId, existingProj);

    res.json({
      ok: true,
      projectId,
      appName: fullProject.appName,
      packageId: fullProject.packageId,
      summary: parsed.summaryHinglish || `${fullProject.appName} ka complete Android Studio Gradle project generate ho gaya hai!`,
      fileCount: Object.keys(fullProject.files).length,
      files: Object.entries(fullProject.files).map(([p, c]) => ({ path: p, content: c })),
      zipBase64,
      usedProvider: aiRes.usedProvider,
      usedModel: aiRes.usedModel,
      fallback: aiRes.fallback || null
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// Download generated Android source ZIP cleanly (No "Library not found" error)
app.get("/api/project-zip", (req, res) => {
  try {
    const projectId = req.query.projectId || "default";
    const proj = dbState.projects[`${req.userId}:${projectId}`];
    if (!proj || !proj.zipBase64) {
      return res.status(404).json({ ok: false, error: "Generated project ZIP abhi available nahi hai." });
    }
    const buf = Buffer.from(proj.zipBase64, "base64");
    const safeSlug = String(proj.appName || "AppBuildProject").replace(/[^a-zA-Z0-9_-]/g, "") || "AppBuildProject";
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${safeSlug}-Android-Source.zip"`);
    res.send(buf);
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// ============================================================================
// 6. CONVERSATIONAL AGENT & PRE-BUILD SOURCE ANALYZER
// ============================================================================
app.post("/api/chat", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const { message, history, projectState, projectId = "default" } = req.body || {};
    if (!message) throw new Error("Message required hai.");

    const proj = dbState.projects[`${ctx.userId}:${projectId}`] || null;
    const checkpointState = {
      projectId,
      appName: proj?.appName || projectState?.appName || "My Android App",
      packageId: proj?.packageId || projectState?.packageId || "com.appbuild.app",
      generatedFilesCount: proj ? Object.keys(proj.files || {}).length : 0,
      projectState: projectState || {}
    };

    const prior = Array.isArray(history)
      ? history.slice(-12).map(m => `${m.role === "model" ? "Agent" : "User"}: ${String(m.text || "").slice(0, 2500)}`).join("\n")
      : "";

    const prompt = `You are App Build AI, a friendly Principal Android App Builder Agent.
Speak naturally in clear, helpful Hinglish.
Capabilities available in this platform:
1. You CAN generate a complete native Android Kotlin + Gradle project directly from the user's natural language idea (via the "Generate Project" or "APK Banaye" action).
2. Users can also attach an existing Android Studio ZIP or source files via the + button.
3. GitHub Cloud Build compiles real installable Release APKs and persistent upload-key signed Play Store AABs.
4. Never claim an APK/AAB build is already compiled until the GitHub Actions run completes and the artifact is verified.

Current Project Checkpoint: ${JSON.stringify(checkpointState)}
Recent Conversation:
${prior}

User: ${String(message).slice(0, 5000)}

Reply in concise Hinglish. Guide the user clearly on the next step.`;

    const result = await aiTextWithCheckpoint(ctx, prompt, checkpointState);
    res.json({
      ok: true,
      reply: result.text,
      usedProvider: result.usedProvider,
      usedModel: result.usedModel,
      fallback: result.fallback || null
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.post("/api/analyze", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const { files, appName, packageId } = req.body || {};
    if (!Array.isArray(files) || !files.length) throw new Error("Analyze karne ke liye source files required hain.");
    if (files.length > 100) throw new Error("Ek baar mein maximum 100 files analyze karein.");
    const allowed = /\.(kt|kts|java|xml|gradle|properties|toml|html|css|js|ts|json|md)$/i;
    const selected = files.filter(f => f && typeof f.path === "string" && typeof f.content === "string" && allowed.test(f.path));
    if (!selected.length) throw new Error("Supported source files nahi mile.");
    const total = selected.reduce((n, f) => n + f.content.length, 0);
    if (total > 180000) throw new Error("AI pre-build review ke liye selected source text 180 KB se kam rakhein.");

    const prompt = [
      "You are App Build's Android project pre-build reviewer.",
      "Review the provided project files for build readiness. Do not claim you compiled or executed anything.",
      "Identify missing Gradle/Android structure, likely compile blockers, manifest/package issues, dependency/configuration risks, signing requirements, and whether this looks like native Android, web-only, or incomplete.",
      "Return concise sections in Hinglish: verdict (READY / NEEDS_FIXES / INCOMPLETE), project_type, blockers, warnings, recommended_fixes, next_step.",
      "App name: " + String(appName || "Unknown"),
      "Package ID: " + String(packageId || "Unknown"),
      "FILES:\n" + selected.map(f => "--- " + f.path + " ---\n" + f.content).join("\n\n")
    ].join("\n\n");

    const result = await aiTextWithCheckpoint(ctx, prompt, { stage: "source_analysis", appName, packageId, fileCount: selected.length });
    res.json({
      ok: true,
      review: result.text,
      usedProvider: result.usedProvider,
      usedModel: result.usedModel,
      fallback: result.fallback || null,
      filesReviewed: selected.length,
      characters: total
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// ============================================================================
// 7. GITHUB CLOUD BUILD AGENT (ISOLATED MULTI-USER WORKSPACES & SIGNING)
// ============================================================================
function extractGithubConfig(ctx) {
  const { owner, repo, token } = ctx;
  if (!owner || !repo || !token) throw new Error("GitHub Owner, Repository aur Token Settings mein required hain.");
  if (!/^[A-Za-z0-9-]+$/.test(owner) || !/^[A-Za-z0-9_.-]+$/.test(repo)) {
    throw new Error("GitHub Owner ya Repository format invalid hai.");
  }
  return { owner, repo, token };
}

async function gh(url, token, options = {}) {
  const r = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/vnd.github+json",
      Authorization: `Bearer ${token}`,
      "X-GitHub-Api-Version": "2022-11-28",
      ...(options.headers || {})
    }
  });
  const body = await r.text();
  let data;
  try {
    data = body ? JSON.parse(body) : {};
  } catch {
    data = { message: body };
  }
  if (!r.ok) throw new Error(data.message || `GitHub API error ${r.status}`);
  return data;
}

// Comprehensive GitHub Connection Test: Verifies Repo, Write Access, and Actions Workflows Access
app.post("/api/test", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const repoData = await gh(`https://api.github.com/repos/${c.owner}/${c.repo}`, c.token);
    if (repoData.permissions && !repoData.permissions.push && !repoData.permissions.admin) {
      throw new Error("Token ke paas repository mein Contents: Read & Write (push) permission nahi hai.");
    }
    await gh(`https://api.github.com/repos/${c.owner}/${c.repo}/actions/workflows`, c.token);
    res.json({
      ok: true,
      repository: repoData.full_name,
      private: repoData.private,
      default_branch: repoData.default_branch,
      permissionsVerified: true
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

async function ensureWorkflowInstalled(c, branch) {
  const workflowPath = ".github/workflows/agent-builder.yml";
  const workflowFile = path.join(__dirname, workflowPath);
  if (!fs.existsSync(workflowFile)) throw new Error("App Build workflow file server par missing hai.");
  const repoUrl = `https://api.github.com/repos/${c.owner}/${c.repo}`;
  const current = await gh(`${repoUrl}/contents/${workflowPath}?ref=${encodeURIComponent(branch)}`, c.token).catch(() => null);
  const content = fs.readFileSync(workflowFile, "utf8");
  if (current?.content) {
    const existing = Buffer.from(current.content.replace(/\n/g, ""), "base64").toString("utf8");
    if (existing.trim() === content.trim()) return;
  }
  await gh(`${repoUrl}/contents/${workflowPath}`, c.token, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message: "App Build v14: install/update isolated Android build workflow",
      content: Buffer.from(content, "utf8").toString("base64"),
      branch,
      ...(current?.sha ? { sha: current.sha } : {})
    })
  });
}

async function getOrCreatePersistentSigningKey(userId, packageId) {
  const safePkg = sanitizePackageId(packageId);
  const keyId = `${userId}:${safePkg}`;
  let record = dbState.signingKeys[keyId];
  if (!record || !record.encryptedPassword) {
    const pass = `AB_${crypto.randomBytes(12).toString("hex")}!`;
    record = {
      userId,
      packageId: safePkg,
      alias: "uploadkey",
      encryptedPassword: encryptSecret(pass),
      createdAt: new Date().toISOString()
    };
    await saveDbRecord("signingKeys", keyId, userId, record);
  }
  return {
    alias: record.alias || "uploadkey",
    password: decryptSecret(record.encryptedPassword)
  };
}

const activeUserBuildLocks = new Set();

async function uploadAndDispatchIsolatedBuild({ ctx, c, cleanBase64Zip, appName, packageId, versionCode, obfuscate, projectId = "default" }) {
  if (activeUserBuildLocks.has(ctx.userId)) {
    throw new Error("Aapka ek build request abhi dispatch ho raha hai. Kripya thoda intezar karein.");
  }
  activeUserBuildLocks.add(ctx.userId);
  try {
    const repoUrl = `https://api.github.com/repos/${c.owner}/${c.repo}`;
    const repo = await gh(repoUrl, c.token);
    const branch = repo.default_branch || "main";
    await ensureWorkflowInstalled(c, branch);

    const buildId = `bld-${Date.now().toString(36)}-${crypto.randomBytes(3).toString("hex")}`;
    // CRITICAL MULTI-USER ISOLATION: Every user and build uses its own isolated path in the repo!
    const workspacePath = `workspaces/${ctx.userId}/${projectId}/${buildId}/project.zip`;

    const existing = await gh(`${repoUrl}/contents/${workspacePath}?ref=${encodeURIComponent(branch)}`, c.token).catch(() => null);
    await gh(`${repoUrl}/contents/${workspacePath}`, c.token, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: `App Build [${buildId}]: upload isolated project for ${ctx.userId}`,
        content: cleanBase64Zip,
        branch,
        ...(existing?.sha ? { sha: existing.sha } : {})
      })
    });

    const signing = await getOrCreatePersistentSigningKey(ctx.userId, packageId);

    await gh(`${repoUrl}/actions/workflows/agent-builder.yml/dispatches`, c.token, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ref: branch,
        inputs: {
          build_id: buildId,
          user_id: ctx.userId,
          workspace_path: workspacePath,
          app_name: String(appName || "AppBuild App").slice(0, 60),
          package_id: sanitizePackageId(packageId, appName).slice(0, 150),
          version_code: String(versionCode || "1"),
          obfuscate: String(Boolean(obfuscate)),
          keystore_base64: "",
          keystore_password: signing.password,
          key_alias: signing.alias
        }
      })
    });

    const buildRecord = {
      id: buildId,
      userId: ctx.userId,
      projectId,
      workspacePath,
      branch,
      appName: String(appName || "AppBuild App"),
      packageId: sanitizePackageId(packageId, appName),
      versionCode: String(versionCode || "1"),
      status: "queued",
      createdAt: new Date().toISOString()
    };
    await saveDbRecord("builds", `${ctx.userId}:${buildId}`, ctx.userId, buildRecord);

    return { buildId, workspacePath, branch };
  } finally {
    activeUserBuildLocks.delete(ctx.userId);
  }
}

app.post("/api/build", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const { fileName, base64, appName, packageId, versionCode, obfuscate, projectId = "default" } = req.body || {};

    let clean = "";
    if (base64) {
      if (fileName && !/\.zip$/i.test(fileName)) throw new Error("Cloud workflow ZIP archive accept karta hai.");
      clean = base64.replace(/^data:.*?;base64,/, "");
    } else {
      // Check if user generated a project in this session
      const proj = dbState.projects[`${ctx.userId}:${projectId}`];
      if (proj && proj.zipBase64) {
        clean = proj.zipBase64;
      }
    }
    if (!clean) throw new Error("Pehle AI se Android project generate karein ya + button se Project ZIP upload karein.");
    if (clean.length > 85_000_000) throw new Error("Project ZIP bahut bada hai (limit approx 60 MB).");

    const info = await uploadAndDispatchIsolatedBuild({
      ctx,
      c,
      cleanBase64Zip: clean,
      appName,
      packageId,
      versionCode,
      obfuscate,
      projectId
    });

    res.json({
      ok: true,
      buildId: info.buildId,
      workspacePath: info.workspacePath,
      branch: info.branch,
      dispatched: true,
      message: `Isolated workspace (${info.buildId}) GitHub par upload ho gaya aur Android build start ho gaya.`
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.post("/api/build-files", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const { files, appName, packageId, versionCode, obfuscate, projectId = "default" } = req.body || {};
    if (!Array.isArray(files) || !files.length) throw new Error("Individual project files required hain.");
    if (files.length > 500) throw new Error("Maximum 500 files allowed.");

    const zip = new AdmZip();
    let total = 0;
    const textFilesMap = {};
    for (const f of files) {
      if (!f || typeof f.path !== "string" || typeof f.base64 !== "string") continue;
      const safe = f.path.replace(/\\/g, "/").replace(/^\/+/, "");
      if (!safe || safe.split("/").some(part => part === ".." || part === "")) throw new Error("Invalid file path: " + f.path);
      const buf = Buffer.from(f.base64.replace(/^data:.*?;base64,/, ""), "base64");
      total += buf.length;
      if (total > 60 * 1024 * 1024) throw new Error("Combined upload size 60 MB se zyada hai.");
      zip.addFile(safe, buf);
      textFilesMap[safe] = true;
    }
    if (!zip.getEntries().length) throw new Error("Valid files nahi mile.");

    // Ensure complete Gradle wrapper config if user only uploaded raw Kotlin/XML files
    if (!textFilesMap["settings.gradle"] && !textFilesMap["settings.gradle.kts"]) {
      const scaffold = buildCompleteAndroidGradleTree({ appName, packageId, versionCode });
      for (const [k, v] of Object.entries(scaffold.files)) {
        if (!zip.getEntry(k)) {
          zip.addFile(k, Buffer.from(v, "utf8"));
        }
      }
    }

    const archive = zip.toBuffer().toString("base64");
    const info = await uploadAndDispatchIsolatedBuild({
      ctx,
      c,
      cleanBase64Zip: archive,
      appName,
      packageId,
      versionCode,
      obfuscate,
      projectId
    });

    res.json({
      ok: true,
      buildId: info.buildId,
      workspacePath: info.workspacePath,
      message: `${zip.getEntries().length} files isolated workspace (${info.buildId}) mein pack karke GitHub par upload hue; workflow dispatch ho gaya.`
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.post("/api/runs", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const { buildId } = req.body || {};
    const data = await gh(`https://api.github.com/repos/${c.owner}/${c.repo}/actions/workflows/agent-builder.yml/runs?per_page=10`, c.token);
    let runs = (data.workflow_runs || []).map(x => ({
      id: x.id,
      name: x.display_title || x.name || "",
      status: x.status,
      conclusion: x.conclusion,
      html_url: x.html_url,
      created_at: x.created_at
    }));
    // Filter to current user's buildId if provided
    if (buildId) {
      const matched = runs.filter(r => r.name.includes(buildId));
      if (matched.length > 0) runs = matched;
    }
    res.json({ ok: true, runs });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.post("/api/artifacts", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const { runId } = req.body || {};
    if (!runId) throw new Error("Run ID missing.");
    const data = await gh(`https://api.github.com/repos/${c.owner}/${c.repo}/actions/runs/${runId}/artifacts`, c.token);
    res.json({
      ok: true,
      artifacts: (data.artifacts || []).map(a => ({
        id: a.id,
        name: a.name,
        size: a.size_in_bytes,
        expired: a.expired,
        archive_download_url: a.archive_download_url
      }))
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

/**
 * Direct APK / AAB / Bundle Download Endpoint:
 * Extracts the actual .apk or .aab binary from GitHub's artifact ZIP so Android phones
 * install the APK directly without any "Library not found" or corrupted archive error!
 */
app.post("/api/artifact-download", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const { artifactId, format = "apk" } = req.body || {};
    if (!artifactId) throw new Error("Artifact ID missing.");

    const r = await fetch(`https://api.github.com/repos/${c.owner}/${c.repo}/actions/artifacts/${artifactId}/zip`, {
      headers: {
        Accept: "application/vnd.github+json",
        Authorization: `Bearer ${c.token}`,
        "X-GitHub-Api-Version": "2022-11-28"
      }
    });
    if (!r.ok) throw new Error(`Artifact download failed: HTTP ${r.status}`);
    const zipBuffer = Buffer.from(await r.arrayBuffer());

    if (format === "apk" || format === "aab") {
      try {
        const archive = new AdmZip(zipBuffer);
        const ext = format === "aab" ? ".aab" : ".apk";
        const entry = archive.getEntries().find(e => !e.isDirectory && e.entryName.toLowerCase().endsWith(ext));
        if (entry) {
          const fileBuf = entry.getData();
          if (fileBuf && fileBuf.length > 1024) {
            const mime = format === "aab" ? "application/octet-stream" : "application/vnd.android.package-archive";
            const fileName = format === "aab" ? "App-PlayStore-Signed-Release.aab" : "App-Installable-Release.apk";
            res.setHeader("Content-Type", mime);
            res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
            return res.send(fileBuf);
          }
        }
      } catch (extractErr) {
        console.warn("[AppBuild] Binary extraction fallback to zip:", extractErr.message);
      }
    }

    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="app-build-artifacts.zip"');
    res.send(zipBuffer);
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// ============================================================================
// 8. BUILD FAILURE DIAGNOSIS & USER-APPROVED AUTO-REPAIR AGENT
// ============================================================================
function safeProjectPath(p) {
  return (
    typeof p === "string" &&
    p.length < 240 &&
    !p.startsWith("/") &&
    !p.split("/").some(x => x === ".." || x === "") &&
    /\.(kt|kts|java|xml|gradle|properties|toml|pro|txt|json|html|css|js|ts)$/i.test(p)
  );
}

async function getRepoProjectZip(c, workspacePath = "project.zip") {
  const repoUrl = `https://api.github.com/repos/${c.owner}/${c.repo}`;
  const repo = await gh(repoUrl, c.token);
  const branch = repo.default_branch || "main";
  let item = await gh(`${repoUrl}/contents/${workspacePath}?ref=${encodeURIComponent(branch)}`, c.token).catch(() => null);
  let actualPath = workspacePath;
  if (!item || !item.content) {
    actualPath = "project.zip";
    item = await gh(`${repoUrl}/contents/project.zip?ref=${encodeURIComponent(branch)}`, c.token);
  }
  if (!item || !item.content) throw new Error("GitHub project archive fetch nahi ho paya.");
  return {
    repoUrl,
    branch,
    workspacePath: actualPath,
    sha: item.sha,
    zip: Buffer.from(item.content.replace(/\n/g, ""), "base64")
  };
}

app.post("/api/diagnose-run", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const { runId, workspacePath = "project.zip" } = req.body || {};
    if (!runId) throw new Error("Run ID required hai.");

    const repoUrl = `https://api.github.com/repos/${c.owner}/${c.repo}`;
    const logResponse = await fetch(`${repoUrl}/actions/runs/${runId}/logs`, {
      headers: {
        Authorization: `Bearer ${c.token}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28"
      }
    });
    if (!logResponse.ok) throw new Error(`GitHub logs fetch failed: ${logResponse.status}`);
    const logZip = new AdmZip(Buffer.from(await logResponse.arrayBuffer()));
    const logs = logZip
      .getEntries()
      .filter(e => !e.isDirectory && /\.(txt|log)$/i.test(e.entryName))
      .map(e => `### ${e.entryName}\n${e.getData().toString("utf8").slice(-18000)}`)
      .join("\n\n")
      .slice(-65000);
    if (!logs) throw new Error("Workflow log archive mein readable text logs nahi mile.");

    const { zip, branch, workspacePath: resolvedPath } = await getRepoProjectZip(c, workspacePath);
    const projectZip = new AdmZip(zip);
    const source = projectZip
      .getEntries()
      .filter(e => !e.isDirectory && safeProjectPath(e.entryName))
      .slice(0, 18)
      .map(e => `--- ${e.entryName} ---\n${e.getData().toString("utf8").slice(0, 7000)}`)
      .join("\n\n")
      .slice(0, 50000);

    const prompt = `You are a senior Android build-failure repair agent. Diagnose these real GitHub Actions logs and project files. Return ONLY valid JSON with shape {"summary":"...","root_cause":"...","confidence":"low|medium|high","fixes":[{"path":"relative/path","content":"COMPLETE replacement file text","reason":"..."}],"manual_steps":["..."]}. Only propose a fix when the cause is evidenced. Include at most 3 complete replacement files, only files present in the project archive. Never modify signing keys, secrets, workflows, gradle wrapper binaries, or unrelated files.\n\nGITHUB ACTIONS LOGS:\n${logs}\n\nPROJECT SOURCE EXCERPTS:\n${source}`;

    const aiResult = await aiTextWithCheckpoint(ctx, prompt, { stage: "diagnose_build_failure", runId, workspacePath: resolvedPath });
    const raw = aiResult.text;
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) throw new Error("Selected AI provider ne valid repair proposal nahi diya: " + raw.slice(0, 500));
    const proposal = JSON.parse(match[0]);
    proposal.fixes = (proposal.fixes || []).filter(f => safeProjectPath(f.path) && typeof f.content === "string" && f.content.length < 50000);

    res.json({
      ok: true,
      runId,
      branch,
      workspacePath: resolvedPath,
      proposal,
      usedProvider: aiResult.usedProvider,
      usedModel: aiResult.usedModel,
      fallback: aiResult.fallback || null
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

app.post("/api/approve-fixes-rerun", async (req, res) => {
  try {
    const ctx = await resolveAndSyncUserContext(req);
    const c = extractGithubConfig(ctx);
    const { fixes, appName, packageId, versionCode, obfuscate, workspacePath = "project.zip", projectId = "default" } = req.body || {};
    if (!Array.isArray(fixes) || !fixes.length || fixes.length > 3) {
      throw new Error("Approve karne ke liye valid suggested fixes required hain.");
    }

    const { zip } = await getRepoProjectZip(c, workspacePath);
    const archive = new AdmZip(zip);
    for (const f of fixes) {
      if (!safeProjectPath(f.path) || typeof f.content !== "string" || f.content.length > 50000) {
        throw new Error("Unsafe ya invalid proposed file change.");
      }
      if (archive.getEntry(f.path)) {
        archive.updateFile(f.path, Buffer.from(f.content, "utf8"));
      } else {
        archive.addFile(f.path, Buffer.from(f.content, "utf8"));
      }
    }

    const info = await uploadAndDispatchIsolatedBuild({
      ctx,
      c,
      cleanBase64Zip: archive.toBuffer().toString("base64"),
      appName,
      packageId,
      versionCode,
      obfuscate,
      projectId
    });

    res.json({
      ok: true,
      buildId: info.buildId,
      workspacePath: info.workspacePath,
      message: `Approved fixes isolated workspace (${info.buildId}) mein apply ho gaye. GitHub Actions rebuild dispatch ho gaya.`
    });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// Health & Graceful Shutdown for Hostinger Node.js Hosting
app.get("/health", (_req, res) => res.json({ ok: true, service: "App Build V14", version: "14.0.0" }));
app.get("/api/health", (_req, res) => res.json({ ok: true, service: "App Build V14", version: "14.0.0" }));

let serverInstance = null;
initDatabase().then(() => {
  if (require.main === module) {
    serverInstance = app.listen(PORT, () => console.log(`App Build V14 listening on port ${PORT}`));
  }
});

process.on("SIGTERM", () => {
  if (serverInstance) serverInstance.close(() => process.exit(0));
});
process.on("SIGINT", () => {
  if (serverInstance) serverInstance.close(() => process.exit(0));
});

module.exports = app;
