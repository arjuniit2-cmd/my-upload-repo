/**
 * App Build V14 — Automated Verification & Multi-User Isolation Test Suite
 * Run with: npm test (or node tests/run-all-tests.js)
 */
const assert = require("assert");
const http = require("http");
const app = require("../server");

function request(server, method, path, body = null, headers = {}) {
  return new Promise((resolve, reject) => {
    const addr = server.address();
    const payload = body ? JSON.stringify(body) : "";
    const req = http.request(
      {
        hostname: "127.0.0.1",
        port: addr.port,
        path,
        method,
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(payload),
          ...headers
        }
      },
      res => {
        let data = "";
        res.on("data", chunk => (data += chunk));
        res.on("end", () => {
          let json = null;
          try {
            json = JSON.parse(data);
          } catch {
            json = { raw: data };
          }
          resolve({ status: res.statusCode, headers: res.headers, body: json });
        });
      }
    );
    req.on("error", reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function runTests() {
  console.log("=== Starting App Build V14 Automated Verification Suite ===");
  const server = app.listen(0);
  const originalFetch = global.fetch;
  let passed = 0;

  try {
    // TEST 1: Health endpoint
    const health = await request(server, "GET", "/api/health");
    assert.strictEqual(health.status, 200);
    assert.strictEqual(health.body.ok, true);
    console.log("✓ PASS 1: Health endpoint (/api/health)");
    passed++;

    // TEST 2: Multi-user isolated session creation (User A vs User B)
    const sessionA = await request(server, "GET", "/api/session");
    const sessionB = await request(server, "GET", "/api/session");
    const cookieA = sessionA.headers["set-cookie"][0].split(";")[0];
    const cookieB = sessionB.headers["set-cookie"][0].split(";")[0];
    assert.notStrictEqual(sessionA.body.userId, sessionB.body.userId);
    console.log("✓ PASS 2: Multi-user distinct session IDs created");
    passed++;

    // TEST 3: Strict Gemini Connection Test (Valid Key vs Invalid 401 Key - Zero Fake Fallback)
    global.fetch = async (url, opts) => {
      if (String(url).includes("generativelanguage.googleapis.com") && String(url).includes("bad-key")) {
        return {
          ok: false,
          status: 401,
          json: async () => ({ error: { message: "API key not valid." } })
        };
      }
      if (String(url).includes("generativelanguage.googleapis.com/v1beta/models?")) {
        return {
          ok: true,
          status: 200,
          json: async () => ({
            models: [{ name: "models/gemini-2.5-flash", displayName: "Gemini 2.5 Flash", supportedGenerationMethods: ["generateContent"] }]
          })
        };
      }
      if (String(url).includes(":generateContent")) {
        return {
          ok: true,
          status: 200,
          json: async () => ({
            candidates: [{ content: { parts: [{ text: "Gemini connection successful." }] } }]
          })
        };
      }
      throw new Error("Unexpected URL: " + url);
    };

    const badGemini = await request(
      server,
      "POST",
      "/api/test-gemini",
      { geminiKey: "bad-key", radoxKey: "valid-radox-key" },
      { Cookie: cookieA }
    );
    assert.strictEqual(badGemini.status, 400);
    assert.strictEqual(badGemini.body.ok, false);
    console.log("✓ PASS 3: Invalid Gemini key returns 400 and NEVER fakes success via Radox backup");
    passed++;

    const goodGemini = await request(
      server,
      "POST",
      "/api/test-gemini",
      { geminiKey: "AIzaValidGeminiKey123456" },
      { Cookie: cookieA }
    );
    assert.strictEqual(goodGemini.status, 200);
    assert.strictEqual(goodGemini.body.ok, true);
    assert.strictEqual(goodGemini.body.provider, "gemini");
    console.log("✓ PASS 4: Valid Gemini key passes direct /api/test-gemini verification");
    passed++;

    // TEST 5: Multi-User Credential Isolation (User B cannot see User A's saved Gemini key)
    const checkA = await request(server, "GET", "/api/session", null, { Cookie: cookieA });
    const checkB = await request(server, "GET", "/api/session", null, { Cookie: cookieB });
    assert.strictEqual(checkA.body.saved.geminiConfigured, true);
    assert.strictEqual(checkB.body.saved.geminiConfigured, false);
    console.log("✓ PASS 5: Multi-user credential vault isolation verified (User B cannot access User A's keys)");
    passed++;

    // TEST 6: Automatic Failover (Gemini HTTP 429 Quota -> Radox AI Resumes with Checkpoint)
    global.fetch = async (url, opts) => {
      if (String(url).includes("generativelanguage.googleapis.com")) {
        return {
          ok: false,
          status: 429,
          json: async () => ({ error: { message: "Resource exhausted (quota exceeded)" } })
        };
      }
      if (String(url).includes("radoxai.com/v1/models")) {
        return {
          ok: true,
          status: 200,
          json: async () => ({ data: [{ id: "deepseek-v4-flash-0731", name: "DeepSeek V4 Flash" }] })
        };
      }
      if (String(url).includes("radoxai.com/v1/chat/completions")) {
        const reqBody = JSON.parse(opts.body);
        const promptSent = reqBody.messages[0].content;
        assert.ok(promptSent.includes("AUTOMATIC FAILOVER RESUME"), "Backup AI must receive checkpoint context");
        return {
          ok: true,
          status: 200,
          json: async () => ({
            choices: [{ message: { content: "Radox resumed from checkpoint and completed the task." } }]
          })
        };
      }
      throw new Error("Unexpected URL in failover test: " + url);
    };

    const failoverChat = await request(
      server,
      "POST",
      "/api/chat",
      {
        provider: "gemini",
        fallbackProvider: "radox",
        radoxKey: "cc_validRadoxKey987654",
        message: "Video player app banao"
      },
      { Cookie: cookieA }
    );
    assert.strictEqual(failoverChat.status, 200);
    assert.strictEqual(failoverChat.body.usedProvider, "radox");
    assert.strictEqual(failoverChat.body.fallback.from, "gemini");
    assert.strictEqual(failoverChat.body.fallback.to, "radox");
    assert.strictEqual(failoverChat.body.fallback.checkpointPreserved, true);
    console.log("✓ PASS 6: Primary Gemini 429 Quota -> Automatic Radox Failover with Checkpoint Preservation");
    passed++;

    // TEST 7: Native Android Project Generation & Isolated Source ZIP Download
    global.fetch = async (url, opts) => {
      return {
        ok: true,
        status: 200,
        json: async () => ({
          candidates: [
            {
              content: {
                parts: [
                  {
                    text: JSON.stringify({
                      appName: "VideoPlayerPro",
                      packageId: "com.appbuild.videoplayerpro",
                      summaryHinglish: "VideoPlayerPro project generated.",
                      mainActivityKt: "package com.appbuild.videoplayerpro\nimport android.os.Bundle\nimport androidx.appcompat.app.AppCompatActivity\nclass MainActivity : AppCompatActivity() { override fun onCreate(b: Bundle?) { super.onCreate(b) } }",
                      activityMainXml: "<?xml version=\"1.0\" encoding=\"utf-8\"?><LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\"/>"
                    })
                  }
                ]
              }
            }
          ]
        })
      };
    };

    const genRes = await request(
      server,
      "POST",
      "/api/generate-project",
      { idea: "Create a video player app", appName: "VideoPlayerPro", packageId: "com.appbuild.videoplayerpro" },
      { Cookie: cookieA }
    );
    assert.strictEqual(genRes.status, 200);
    assert.strictEqual(genRes.body.ok, true);
    assert.ok(genRes.body.fileCount >= 8);
    console.log("✓ PASS 7: Native Android Gradle + Kotlin project generated (/api/generate-project)");
    passed++;

    // Verify User B cannot download User A's generated project ZIP
    const zipUserB = await request(server, "GET", "/api/project-zip?projectId=default", null, { Cookie: cookieB });
    assert.strictEqual(zipUserB.status, 404);
    console.log("✓ PASS 8: Multi-user project isolation verified (User B cannot download User A's project ZIP)");
    passed++;

    console.log(`\nALL ${passed} AUTOMATED TESTS PASSED SUCCESSFULLY!`);
  } finally {
    global.fetch = originalFetch;
    server.close();
  }
}

runTests().catch(err => {
  console.error("Test suite failed:", err);
  process.exit(1);
});
